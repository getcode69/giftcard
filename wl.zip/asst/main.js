$(document).ready(function() {

	$('.app-link-wrapper a').tooltipster({
		theme: 'tooltipster-borderless',
		animation: 'grow',
		delay: 300
	});
	
});
